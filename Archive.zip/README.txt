---------------------------
Project 3 
Anthony Terrell Snow Jr. 
---------------------------

Included: 
Project3.php - the main file
README.txt - this file 

This is my implementation of Project3. my form performs said searches and returns the output of a entire game. Program dynamically populates both the Files and Stats options, it is also able to properly read files (once they are validated) for Statistics (if they are validated as well). Code is very well documented and to my best attempt has good coding practices. Everything that was needed to be hard-coded is, everyhing is dynamically populated. Errors are also shown when you try to input a file or statistics name into the url. Program does not crash. 

*Also, in the case of 2 games having the same value, I chose to only input one. I chose this because honestly it was the easiest way. No use in complicating things. 

*I did not do validation for the function call because it was not specified in the rubric 


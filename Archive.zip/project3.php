<?php

// Anthony Snow  

	$UKgames = "UKgames.json"; //contsant, this will be used more than once


	/*Since everything is in one file, we need to load the page once 
	to set the variable, When we have set the variables, it changes the 
	display on the page. */
	if (isset($_GET['fileToSearch'])) {
		process_form();
	} else {
		display_form();
	}


	// starter code given to us
	function start_html(){
		echo "
		<html> 
		<head>
			<title> Project 3 </title>
		<head>
		<h1 Search Field</h1>"; 
		
	}

	function end_html(){
		echo "
		</body>
		</html>"; 
	}

	/*processed the said form when variables are set. we send the file info, statistic info, and function info to a variable called do search*/
	function process_form() {

		$myError = 0; 
		$fileToSearch = $_GET['fileToSearch']; 
		$filecontentsValue = key_to_value($fileToSearch); 
		checkFile($filecontentsValue); 
		$filecontents = file_get_contents($filecontentsValue); 


		$theStat = $_GET['statToSearch']; 
		$theFunct =$_GET['functWanted']; 
		dosearch($filecontents, $theStat, $theFunct); 

	}

	// this function right here traverses through the given json file. 
	function doSearch($f, $s, $w) {

	    $currStat = null;


		$gamesJSON = json_decode($f); 
		$fval = null; 
		$fgame = null; 
		echo $gamesJSON->games->$s; 

		 foreach ($gamesJSON->games as $agame) { // traverse through each game in file

		 	if (!isset($agame->$s)) { // if the statistic doenst exist
		 		 echo "Statistic youre searching for doesn't exist<br>"; 
		 		 $error = 1; 
		 		 break;

		 	}
		 	if ($fval == null && $fgame == null) {
		 		$fval = $agame->$s; 
		 		$fgame = $agame; 
		 	} else  if ($w == 'high') { // greater than 
		 		if (($agame->$s) > $fval) { // decided to just print one

		 			$fval = $agame->$s; 
		 			$fgame = $agame; 
		 		}

		 	} elseif ($w == 'low') { //lesser than
		 		if (($agame->$s) < $fval) { // decided to just print one

		 			$fval = $agame->$s; 
		 			$fgame = $agame;
		 		}
		 	}
		 }
		if ($error == 1) {
				return; // return, no need to print out bottom part
			} 
		echo "the ". $w . "est of stat ". $s;
		echo "<br><br>"; 


		// echo "<br>"; 
		// echo "Opponent" . $fgame->Opponent; 
		// echo "<br>"; 
		// echo "Date" . $fgame->Date; 
		// echo "WinorLose" . $fgame->WinorLose; 
		// echo "<br>"; 
		// echo "Fouls" . $fgame->Fouls; 
		// echo "<br>"; 
		// echo "Assists" . $fgame->Assists; 
		// echo "<br>"; 
		// echo "Turnovers" . $fgame->Turnovers; 
		// echo "<br>"; 
		// echo "Blocks: " . $fgame->Blocks; 
		// echo "<br>"; 
		// echo "Steals" . $fgame->Steals; 
		// echo "<br>"; 
		// echo "Points" . $fgame->Points;
		// echo "<br>"; 
		// echo "YeartoDateAvg" . $fgame->YeartoDateAvg; 
		// echo "<br><br>";

		// better way of doing this 
		foreach ($fgame as $key2=> $value2) { // traverse through each stat of game
			echo $key2;
			echo ": "; 
			echo $value2;
		 	echo "<br>"; 
		 } 



		return; 
	}


	// displays the html form using php. pretty simple
	function display_form(){ 


		$fileDropDown =""; // good practice to intialize variable
		$statDropDown =""; //although in php you dont have to
		$fileFile = ""; 
		$statFile = ""; 

		$string = file_get_contents("UKgames.json"); 
		$results = json_decode($string);


		      

		foreach ($results->files as $key => $value) {
			$fileDropDown = $fileDropDown . "<option type='text' value=" . $key . ">" . $key .   "</option>";
		}
		foreach ($results->stats as $key => $value) {
			$statDropDown = $statDropDown . "<option type='text' value=" . $value . ">" . $value .   "</option>";
		}


		start_html();



		echo "
		<form action='project3.php' method='get'>
		Select parameters to search:<br>
		";
		echo "
		<p>
		<select name='fileToSearch'> ";

	           echo $fileDropDown; // dynamically populates!

		echo "</select>";

		echo "
		<p>
		<select name='statToSearch'> ";

	           echo $statDropDown; // dynamically populates!

		echo "</select>";

		echo "
		<p>
		<select name='functWanted'> ";
			echo "<option value='high'>High</option>";
			echo "<option value='low'>Low</option>";
		echo "</select>";

		echo "
		<p>
		<input type='submit' value='Do search'>
		";
		end_html(); 
	}
	// returns the value (filename) of the key
	function key_to_value($key){

		$string = file_get_contents("UKgames.json"); //okay to hardcode this file
		$results = json_decode($string);
		$value = $results ->files -> $key;

		return $value; 
	}
 	// check file to see if it exists AND if it files the format[a-zA-z0-9].json
	function checkFile($file){
		if (file_exists($file)) { 
			echo "file exists! <br>";
		} else {
			echo "file doesnt exist <br>";
			return false; 
		}
		if (preg_match('([[:alnum:].(json)])', $file)){
			echo " proper form! <br>"; 
		} else {
			echo "<br> validation not passed <br>";
			return false; 
		}
		return true; 
	}


?>